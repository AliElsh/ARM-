#ifndef SPI_Config_h
#define SPI_Config_h

#define SPI_MASTER     0
#define SPI_SLAVE      1


/*   SPI_MASTER  & SPI_SLAVE   */
#define SPI_MODE       SPI_MASTER


#endif